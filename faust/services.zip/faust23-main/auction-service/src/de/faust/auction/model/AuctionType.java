package de.faust.auction.model;

public enum AuctionType {
    NORMAL,
    
    BUY_IT_NOW
}
