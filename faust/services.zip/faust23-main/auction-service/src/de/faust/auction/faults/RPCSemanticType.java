package de.faust.auction.faults;

public enum RPCSemanticType {
    LAST_OF_MANY, AT_MOST_ONCE
}
