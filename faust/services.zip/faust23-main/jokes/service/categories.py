category_list = ["Dad", "Sports", "Family", "Blonde", "Political", "Other"]
